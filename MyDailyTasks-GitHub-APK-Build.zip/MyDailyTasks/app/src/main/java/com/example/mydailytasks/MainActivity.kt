package com.example.mydailytasks

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.lifecycleScope
import com.example.mydailytasks.alarm.ReminderScheduler
import com.example.mydailytasks.data.TaskDatabase
import com.example.mydailytasks.data.TaskEntity
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    private val dao by lazy { TaskDatabase.get(this).taskDao() }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 10)
        setContent {
            val tasks by dao.observeAll().collectAsState(initial = emptyList())
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF365E52), secondary = Color(0xFF6E8B80), background = Color(0xFFF5F7F5))) {
                Surface(Modifier.fillMaxSize(), color = Color(0xFFF5F7F5)) {
                    Column(Modifier.fillMaxSize().padding(16.dp)) {
                        Text("My Daily Tasks", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Color(0xFF203D34))
                        Text("A simple list to keep your day on track", color = Color(0xFF68756F), fontSize = 14.sp)
                        Spacer(Modifier.height(16.dp))
                        var newTask by remember { mutableStateOf("") }
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            OutlinedTextField(value = newTask, onValueChange = { newTask = it }, modifier = Modifier.weight(1f), placeholder = { Text("Add a new task…") }, singleLine = true, shape = RoundedCornerShape(14.dp))
                            Spacer(Modifier.width(8.dp))
                            FilledIconButton(onClick = { val text = newTask.trim(); if (text.isNotEmpty()) { lifecycleScope.launch { dao.insert(TaskEntity(title = text)) }; newTask = "" } }, modifier = Modifier.size(52.dp)) { Icon(Icons.Default.Add, contentDescription = "Add task") }
                        }
                        Spacer(Modifier.height(14.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text("#", Modifier.width(28.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("TASK / DONE", Modifier.weight(1.7f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("REMINDER", Modifier.weight(1.2f), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Text("SOUND", Modifier.width(48.dp), fontSize = 10.sp, fontWeight = FontWeight.Bold, color = Color.Gray)
                            Spacer(Modifier.width(34.dp))
                        }
                        HorizontalDivider(color = Color(0xFFDDE5E0))
                        if (tasks.isEmpty()) {
                            Column(Modifier.fillMaxWidth().weight(1f), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                Text("✦", fontSize = 36.sp, color = Color(0xFF8BA99B))
                                Text("Your list starts here", fontWeight = FontWeight.SemiBold, fontSize = 18.sp, color = Color(0xFF365E52))
                                Text("Add a task above, then set a reminder.", color = Color.Gray, fontSize = 13.sp)
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 8.dp)) {
                                itemsIndexed(tasks, key = { _, task -> task.id }) { index, task ->
                                    TaskRow(index + 1, task,
                                        onDone = { updated -> lifecycleScope.launch { dao.update(updated) } },
                                        onReminder = { chooseReminder(task) },
                                        onAlarm = { enabled -> lifecycleScope.launch { val updated = task.copy(alarmEnabled = enabled); dao.update(updated); if (updated.reminderAt != null) ReminderScheduler.schedule(this@MainActivity, updated) } },
                                        onDelete = { lifecycleScope.launch { ReminderScheduler.cancel(this@MainActivity, task.id); dao.delete(task) } })
                                    HorizontalDivider(color = Color(0xFFE4EAE6))
                                }
                            }
                        }
                        Text("${tasks.count { !it.done }} pending  ·  ${tasks.count { it.done }} completed", modifier = Modifier.fillMaxWidth().padding(top = 10.dp), color = Color(0xFF68756F), fontSize = 12.sp)
                    }
                }
            }
        }
    }
    private fun chooseReminder(task: TaskEntity) {
        val cal = Calendar.getInstance().apply { timeInMillis = task.reminderAt ?: System.currentTimeMillis() }
        DatePickerDialog(this, { _, year, month, day ->
            cal.set(Calendar.YEAR, year); cal.set(Calendar.MONTH, month); cal.set(Calendar.DAY_OF_MONTH, day)
            TimePickerDialog(this, { _, hour, minute ->
                cal.set(Calendar.HOUR_OF_DAY, hour); cal.set(Calendar.MINUTE, minute); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
                lifecycleScope.launch { val updated = task.copy(reminderAt = cal.timeInMillis); dao.update(updated); ReminderScheduler.schedule(this@MainActivity, updated) }
            }, cal.get(Calendar.HOUR_OF_DAY), cal.get(Calendar.MINUTE), false).show()
        }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
    }
}

@Composable
private fun TaskRow(number: Int, task: TaskEntity, onDone: (TaskEntity) -> Unit, onReminder: () -> Unit, onAlarm: (Boolean) -> Unit, onDelete: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(number.toString(), Modifier.width(28.dp), fontSize = 13.sp, color = Color(0xFF6C7A73))
        Column(Modifier.weight(1.7f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Checkbox(checked = task.done, onCheckedChange = { onDone(task.copy(done = it)) }, modifier = Modifier.size(30.dp))
                Spacer(Modifier.width(4.dp))
                Text(task.title, fontSize = 14.sp, color = if (task.done) Color.Gray else Color(0xFF243A31), fontWeight = FontWeight.Medium, maxLines = 3)
            }
            if (task.done) Text("COMPLETED", Modifier.padding(start = 34.dp), color = Color(0xFF49816A), fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
        Column(Modifier.weight(1.2f), horizontalAlignment = Alignment.CenterHorizontally) {
            TextButton(onClick = onReminder, contentPadding = PaddingValues(horizontal = 2.dp, vertical = 4.dp)) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(if (task.reminderAt == null) "Set time +" else SimpleDateFormat("MMM d", Locale.getDefault()).format(Date(task.reminderAt)), fontSize = 12.sp, color = Color(0xFF365E52))
                    Text(if (task.reminderAt == null) "date" else SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date(task.reminderAt)), fontSize = 11.sp, color = Color.Gray)
                }
            }
        }
        Checkbox(checked = task.alarmEnabled, onCheckedChange = onAlarm, modifier = Modifier.width(48.dp).size(30.dp))
        IconButton(onClick = onDelete, modifier = Modifier.size(34.dp)) { Icon(Icons.Default.Delete, contentDescription = "Delete task", tint = Color(0xFFB45B56), modifier = Modifier.size(19.dp)) }
    }
}
