package com.example.mydailytasks.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks ORDER BY id ASC") fun observeAll(): Flow<List<TaskEntity>>
    @Insert suspend fun insert(task: TaskEntity): Long
    @Update suspend fun update(task: TaskEntity)
    @Delete suspend fun delete(task: TaskEntity)
    @Query("SELECT * FROM tasks WHERE reminderAt IS NOT NULL AND alarmEnabled = 1") suspend fun reminders(): List<TaskEntity>
}
