package com.example.mydailytasks.alarm

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.mydailytasks.MainActivity

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val manager = context.getSystemService(NotificationManager::class.java)
        val soundOn = intent.getBooleanExtra("alarmEnabled", true)
        val channelId = if (soundOn) "task_reminders_sound" else "task_reminders_silent"
        if (Build.VERSION.SDK_INT >= 26) {
            manager.createNotificationChannel(NotificationChannel("task_reminders_sound", "Task reminders with sound", NotificationManager.IMPORTANCE_HIGH).apply { description = "Daily reminders with sound" })
            manager.createNotificationChannel(NotificationChannel("task_reminders_silent", "Silent task reminders", NotificationManager.IMPORTANCE_LOW).apply { description = "Daily reminders without sound"; setSound(null, null); enableVibration(false) })
        }
        val title = intent.getStringExtra("taskTitle") ?: "Your task is due"
        val open = PendingIntent.getActivity(context, 0, Intent(context, MainActivity::class.java), PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        manager.notify((intent.getLongExtra("taskId", 1L) % Int.MAX_VALUE).toInt(), NotificationCompat.Builder(context, channelId)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle("Task reminder").setContentText(title)
            .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(open).build())
        val id = intent.getLongExtra("taskId", -1L)
        val titleText = intent.getStringExtra("taskTitle") ?: return
        if (id >= 0) {
            val reminderAt = intent.getLongExtra("reminderAt", System.currentTimeMillis())
            val sound = intent.getBooleanExtra("alarmEnabled", true)
            val next = Intent(context, ReminderReceiver::class.java).apply {
                putExtra("taskId", id); putExtra("taskTitle", titleText)
                putExtra("reminderAt", reminderAt); putExtra("alarmEnabled", sound)
            }
            val pi = PendingIntent.getBroadcast(context, id.toInt(), next, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
            val at = ReminderScheduler.nextDaily(reminderAt)
            context.getSystemService(android.app.AlarmManager::class.java).setAndAllowWhileIdle(android.app.AlarmManager.RTC_WAKEUP, at, pi)
        }
    }
}
