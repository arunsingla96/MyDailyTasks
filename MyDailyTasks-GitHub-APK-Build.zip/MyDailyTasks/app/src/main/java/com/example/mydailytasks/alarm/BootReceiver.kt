package com.example.mydailytasks.alarm

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.mydailytasks.data.TaskDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        CoroutineScope(Dispatchers.IO).launch {
            try { TaskDatabase.get(context).taskDao().reminders().forEach { ReminderScheduler.schedule(context, it) } }
            finally { pending.finish() }
        }
    }
}
